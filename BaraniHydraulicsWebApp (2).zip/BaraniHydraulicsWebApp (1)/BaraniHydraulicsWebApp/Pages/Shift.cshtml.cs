using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BaraniHydraulicsWebApp.Pages
{
    public class ShiftModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
