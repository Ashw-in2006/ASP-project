using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BaraniHydraulicsWebApp.Pages
{
    public class ShiftModel : PageModel
    {
        public void OnGet()
        {
            // Logic for GET requests (initial page load)
        }

        public void OnPost()
        {
            // Logic for POST requests (form submission)
        }
    }
}
