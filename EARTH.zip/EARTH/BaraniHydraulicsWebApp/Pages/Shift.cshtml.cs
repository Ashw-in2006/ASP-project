using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BaraniHydraulicsWebApp.Pages
{
    public class ShiftModel : PageModel
    {
        [BindProperty]
        public string FromDate { get; set; }

        [BindProperty]
        public string ToDate { get; set; }

        public string ChartDataJson { get; set; }

        public void OnPost()
        {
            // Path to the Excel file (moved out of wwwroot)
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "Data", "ShiftData.xlsx");

            try
            {
                using (var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                using (var package = new ExcelPackage(stream))
                {
                    var worksheet = package.Workbook.Worksheets[0];
                    var rows = worksheet.Dimension.Rows;

                    // Read and filter Excel data
                    var data = new List<ShiftData>();
                    for (int row = 2; row <= rows; row++) // Skip header row
                    {
                        var logDateTime = DateTime.Parse(worksheet.Cells[row, 1].Text); // LOGDATETIME
                        var productionCount = int.Parse(worksheet.Cells[row, 4].Text); // ProductionCount

                        if (!string.IsNullOrEmpty(FromDate) && !string.IsNullOrEmpty(ToDate))
                        {
                            var fromDate = DateTime.Parse(FromDate);
                            var toDate = DateTime.Parse(ToDate);
                            if (logDateTime < fromDate || logDateTime > toDate) continue;
                        }

                        data.Add(new ShiftData
                        {
                            LogDateTime = logDateTime,
                            ProductionCount = productionCount
                        });
                    }

                    // Aggregate data for Chart.js
                    var aggregatedData = data
                        .GroupBy(d => d.LogDateTime.Date)
                        .Select(g => new { Date = g.Key.ToString("yyyy-MM-dd"), TotalCount = g.Sum(x => x.ProductionCount) })
                        .OrderBy(item => item.Date)
                        .ToList();

                    // Convert to JSON
                    ChartDataJson = System.Text.Json.JsonSerializer.Serialize(aggregatedData);
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine($"Error accessing file: {ex.Message}");
                // Log error or notify the user
            }
        }
    }

    public class ShiftData
    {
        public DateTime LogDateTime { get; set; }
        public int ProductionCount { get; set; }
    }
}
