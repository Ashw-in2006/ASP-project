namespace BaraniHydraulicsWebApp.Models
{
    public class ShiftData
    {
        public DateTime LogDateTime { get; set; }
        public int ProductionCount { get; set; }
    }
}
